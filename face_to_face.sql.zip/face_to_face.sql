-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 04, 2015 at 07:52 AM
-- Server version: 5.6.26
-- PHP Version: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `face_to_face`
--
CREATE DATABASE IF NOT EXISTS `face_to_face` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `face_to_face`;

-- --------------------------------------------------------

--
-- Table structure for table `meetups`
--

CREATE TABLE IF NOT EXISTS `meetups` (
  `id` int(11) NOT NULL,
  `user1_id` int(11) DEFAULT NULL,
  `user2_id` int(11) DEFAULT NULL,
  `user1_confirm` tinyint(1) DEFAULT NULL,
  `user2_confirm` tinyint(1) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `confirm_meet_usr1` tinyint(1) DEFAULT NULL,
  `confirm_meet_usr2` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `meetups`
--

INSERT INTO `meetups` (`id`, `user1_id`, `user2_id`, `user1_confirm`, `user2_confirm`, `location_id`, `confirm_meet_usr1`, `confirm_meet_usr2`) VALUES
(1, 6, 1, 1, 1, 1, NULL, NULL),
(2, 6, 2, 1, 0, 1, NULL, NULL),
(3, 6, 3, 1, NULL, 1, NULL, NULL),
(4, 4, 6, 1, NULL, 1, NULL, NULL),
(5, 5, 6, 1, NULL, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `places`
--

CREATE TABLE IF NOT EXISTS `places` (
  `id` int(11) NOT NULL,
  `place_name` varchar(40) NOT NULL,
  `address` varchar(40) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `places`
--

INSERT INTO `places` (`id`, `place_name`, `address`, `latitude`, `longitude`) VALUES
(1, 'Portland City Grill', '111 5th Ave Portland, OR 97204', 45.522755, -122.675859),
(2, 'Pioneer Courthouse Square', '701 SW 6th Ave Portland, OR 97204', 45.518847, -122.679256),
(3, 'Powell''s City of Books', '1005 W Burnside St Portland, OR 97209', 45.523113, -122.681386);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(40) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `signed_in` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`, `latitude`, `longitude`, `signed_in`) VALUES
(1, 'Test_Meet', '$2y$12$7MU5DY7UVJ2BMb65iXwP8uAXyJR1u/XCqCmwGuHH51hBlnc8eT1Si', 45.522153, -122.676996, 1),
(2, 'Test_Reject', '$2y$12$7MU5DY7UVJ2BMb65iXwP8uAXyJR1u/XCqCmwGuHH51hBlnc8eT1Si', 45.520958, -122.676288, 1),
(3, 'Test_Wait', '$2y$12$7MU5DY7UVJ2BMb65iXwP8uAXyJR1u/XCqCmwGuHH51hBlnc8eT1Si', 45.520387, -122.677994, 1),
(4, 'Test_Accept', '$2y$12$7MU5DY7UVJ2BMb65iXwP8uAXyJR1u/XCqCmwGuHH51hBlnc8eT1Si', 45.52059, -122.675505, 1),
(5, 'Test_Reject_Request', '$2y$12$7MU5DY7UVJ2BMb65iXwP8uAXyJR1u/XCqCmwGuHH51hBlnc8eT1Si', 45.522214, -122.674561, 1),
(6, 'Master', '$2y$12$7MU5DY7UVJ2BMb65iXwP8uAXyJR1u/XCqCmwGuHH51hBlnc8eT1Si', 45.516231, -122.682519, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `meetups`
--
ALTER TABLE `meetups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `places`
--
ALTER TABLE `places`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `meetups`
--
ALTER TABLE `meetups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `places`
--
ALTER TABLE `places`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
